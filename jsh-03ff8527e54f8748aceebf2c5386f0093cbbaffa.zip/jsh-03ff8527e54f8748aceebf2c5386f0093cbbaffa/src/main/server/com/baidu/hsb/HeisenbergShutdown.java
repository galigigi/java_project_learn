/**
 * Baidu.com,Inc.
 * Copyright (c) 2000-2013 All Rights Reserved.
 */
package com.baidu.hsb;

import java.util.Date;

/**
 * 
 * 
 * @author xiongzhao@baidu.com
 * @version $Id: CobarShutdown.java, v 0.1 2013年12月31日 下午1:40:21 HI:brucest0078 Exp $
 */
public final class HeisenbergShutdown {

    public static void main(String[] args) {
        System.out.println(new Date() + ",server shutdown!");
    }

}
