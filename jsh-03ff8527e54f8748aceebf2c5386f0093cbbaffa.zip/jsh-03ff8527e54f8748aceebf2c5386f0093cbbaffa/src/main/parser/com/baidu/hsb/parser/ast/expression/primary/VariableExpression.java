/**
 * Baidu.com,Inc.
 * Copyright (c) 2000-2013 All Rights Reserved.
 */
package com.baidu.hsb.parser.ast.expression.primary;

/**
 * @author xiongzhao@baidu.com
 */
public abstract class VariableExpression extends PrimaryExpression {
}
