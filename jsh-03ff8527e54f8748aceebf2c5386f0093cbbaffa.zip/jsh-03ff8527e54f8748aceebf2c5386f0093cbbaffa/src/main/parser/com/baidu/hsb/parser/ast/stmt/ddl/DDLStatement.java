/**
 * Baidu.com,Inc.
 * Copyright (c) 2000-2013 All Rights Reserved.
 */
package com.baidu.hsb.parser.ast.stmt.ddl;

import com.baidu.hsb.parser.ast.stmt.SQLStatement;

/**
 * NOT FULL AST
 * 
 * @author xiongzhao@baidu.com
 */
public interface DDLStatement extends SQLStatement {
    //QS_TODO ddl regenerate sql by router
}
