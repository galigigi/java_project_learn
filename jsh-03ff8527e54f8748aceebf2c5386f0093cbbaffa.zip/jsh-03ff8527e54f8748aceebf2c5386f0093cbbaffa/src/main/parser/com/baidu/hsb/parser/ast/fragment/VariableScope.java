/**
 * Baidu.com,Inc.
 * Copyright (c) 2000-2013 All Rights Reserved.
 */
package com.baidu.hsb.parser.ast.fragment;

/**
 * @author xiongzhao@baidu.com
 */
public enum VariableScope {
    SESSION,
    GLOBAL
}
